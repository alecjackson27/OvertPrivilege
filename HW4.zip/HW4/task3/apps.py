from django.apps import AppConfig


class Task3(AppConfig):
    name = 'task3'
