# Replacements Considered

## Replacements considered for task 1:
mirroring (e.g. 'password' -> 'drowssap')
Capitalize just first letter
e/E -> 3
a/A -> @
i/I -> !
s/S -> $
s/S -> 5
add a digit from 1 to 9 at the end
add a digit from 1 to 9 at the penultimate position
add any special character in ('!, '@', '#', '$', '*', '&') to the end
repeat word
repeat word thrice

## Replacements considered for task 2:
e/E -> 3
a/A -> @
i/I -> !
s/S -> $
s/S -> 5
Capitalize just first letter
swap case (e.g. 'password' -> 'pASSWORD')
ALL CAPS
